package pt.meic.sec;

public enum ReadType {
    PublicKeyBlock,
    ContentBlock
}
