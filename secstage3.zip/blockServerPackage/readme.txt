1 build server and shared

> build.bat

2 Running the program 

> run.bat

